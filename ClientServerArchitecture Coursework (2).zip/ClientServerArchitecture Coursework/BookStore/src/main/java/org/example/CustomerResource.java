package org.example;


import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.example.Customer;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Path("/customers")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CustomerResource {

    private static Map<Integer, Customer> customers = Database.customers;
    private static AtomicInteger customerIdCounter = Database.customerIdCounter;


    @POST
    public Response createCustomer(Customer customer) {
        int id = customerIdCounter.getAndIncrement();
        customer.setId(id);
        customers.put(id, customer);
        return Response.status(Response.Status.CREATED).entity(customer).build();
    }

    @GET
    public Collection<Customer> getAllCustomers() {
        return customers.values();
    }

    @GET
    @Path("/{id}")
    public Response getCustomer(@PathParam("id") int id) {
        Customer customer = customers.get(id);
        if (customer == null) {throw new CustomerNotFoundException("Customer with ID" + id + " not found");}
        return Response.ok(customer).build();
    }

    @PUT
    @Path("/{id}")
    public Response updateCustomer(@PathParam("id") int id, Customer updatedCustomer) {
        Customer existing = customers.get(id);
        if (existing == null) throw new CustomerNotFoundException("Customer with ID" + id + " not found");
        updatedCustomer.setId(id);
        customers.put(id, updatedCustomer);
        return Response.ok(updatedCustomer).build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteCustomer(@PathParam("id") int id) {
        Customer removed = customers.remove(id);
        if (removed == null) throw new CustomerNotFoundException("Customer with ID" + id + " not found");
        return Response.noContent().build();
    }

    public static Map<Integer, Customer> getCustomerDB() {
        return customers;
    }
}
