package org.example;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;
import java.util.Map;
public class Order {
    private int id;
    private int customerId;
    private List<CartItem> cartItems;
    private double totalPrice;
    private LocalDateTime orderDate;

    public Order() {}

    public Order(int id, int customerId, List<CartItem> cartItems, double totalPrice, LocalDateTime orderDate) {
        this.id = id;
        this.customerId = customerId;
        this.cartItems = cartItems;
        this.totalPrice = totalPrice;
        this.orderDate = LocalDateTime.now();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }
}
