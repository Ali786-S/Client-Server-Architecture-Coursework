package org.example;

import jakarta.ws.rs.core.*;
        import jakarta.ws.rs.ext.*;

@Provider
public class InvalidInputMapper implements ExceptionMapper<InvalidInputException> {
    @Override
    public Response toResponse(InvalidInputException ex) {
        return Response.status(Response.Status.BAD_REQUEST)
                .entity(new ErrorMessage("Invalid Input", ex.getMessage()))
                .type(MediaType.APPLICATION_JSON)
                .build();
    }
}
