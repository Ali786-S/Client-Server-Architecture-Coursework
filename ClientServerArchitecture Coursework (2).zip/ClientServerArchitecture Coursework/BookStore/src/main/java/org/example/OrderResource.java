package org.example;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Path("/customers/{customerId}/orders")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class OrderResource {

    private static Map<Integer, List<Order>> orderDB = Database.orders;
    private static Map<Integer, List<CartItem>> cartDB = Database.carts;
    private static AtomicInteger orderIdCounter = Database.orderIdCounter;

    @POST
    public Response placeOrder(@PathParam("customerId") int customerId) {
        List<CartItem> cart = cartDB.get(customerId);
        if (cart == null || cart.isEmpty()) {
            throw new CartNotFoundException("Cart is empty or does not exist for customer ID: " + customerId);
        }

        double total = 0;
        for (CartItem item : cart) {
            Book book = Database.books.get(item.getBookId());
            if (book != null) {
                total += book.getPrice() * item.getQuantity();
            }
        }

        Order order = new Order(
                orderIdCounter.getAndIncrement(),
                customerId,
                new ArrayList<>(cart),
                total,
                LocalDateTime.now()
        );

        orderDB.putIfAbsent(customerId, new ArrayList<>());
        orderDB.get(customerId).add(order);

        cart.clear();

        return Response.status(Response.Status.CREATED).entity(order).build();
    }

    @GET
    public Response getOrders(@PathParam("customerId") int customerId) {
        return Response.ok(orderDB.getOrDefault(customerId, new ArrayList<>())).build();
    }

    @GET
    @Path("/{orderId}")
    public Response getOrder(@PathParam("customerId") int customerId, @PathParam("orderId") int orderId) {
        List<Order> orders = orderDB.get(customerId);
        if (orders == null) throw new OutOfStockException("No orders found.");

        for (Order o : orders) {
            if (o.getId() == orderId) return Response.ok(o).build();
        }

        throw new OutOfStockException("Order not found.");
    }
}
