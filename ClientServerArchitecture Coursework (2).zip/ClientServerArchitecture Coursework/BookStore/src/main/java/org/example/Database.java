package org.example;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Database {

    public static Map<Integer, Book> books = new HashMap<>();
    public static Map<Integer, Author> authors = new HashMap<>();
    public static Map<Integer, Customer> customers = new HashMap<>();
    public static Map<Integer, List<CartItem>> carts = new HashMap<>();
    public static Map<Integer, List<Order>> orders = new HashMap<>();


    public static AtomicInteger bookIdCounter = new AtomicInteger(1);
    public static AtomicInteger authorIdCounter = new AtomicInteger(1);
    public static AtomicInteger customerIdCounter = new AtomicInteger(1);
    public static AtomicInteger orderIdCounter = new AtomicInteger(1);
}
