package org.example;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;


import org.example.BookResource;
import org.example.AuthorResource;
import org.example.CustomerResource;
import org.example.CartResource;
import org.example.OrderResource;

import java.util.HashSet;
import java.util.Set;

/**
 * Application configuration class for JAX-RS.
 * This registers all REST resource classes and sets the base API path to /api.
 */
@ApplicationPath("/api")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<>();
        resources.add(BookResource.class);
        resources.add(AuthorResource.class);
        resources.add(CustomerResource.class);
        resources.add(CartResource.class);
        resources.add(OrderResource.class);

        resources.add(AuthorNotFoundMapper.class);
        resources.add(BookNotFoundMapper.class);
        resources.add(CustomerNotFoundMapper.class);
        resources.add(CartNotFoundMapper.class);
        resources.add(OutofStockMapper.class);
        resources.add(InvalidInputMapper.class);


        return resources;
    }
}
