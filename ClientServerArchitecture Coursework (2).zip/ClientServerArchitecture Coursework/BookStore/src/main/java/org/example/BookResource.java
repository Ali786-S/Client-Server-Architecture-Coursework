package org.example;


import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.example.Book;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Path("/books")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BookResource {

    private static Map<Integer, Book> bookDB = new HashMap<>();
    private static AtomicInteger idCounter = new AtomicInteger(1);

    @POST
    public Response createBook(Book book) {
        if (book.getTitle() == null || book.getTitle().trim().isEmpty()) {
            throw new InvalidInputException("Book title must not be empty");
        }
        if (book.getPrice() < 0) {
            throw new InvalidInputException("Book price must be a positive value.");
        }
        if (book.getStock() < 0) {
            throw new InvalidInputException("Book stock must be a positive integer.");
        }
        if (!Database.authors.containsKey(book.getAuthorId())) {
            throw new AuthorNotFoundException("Author with ID: " + book.getAuthorId() + " not found.");
        }
        int id = Database.bookIdCounter.getAndIncrement();
        book.setId(id);
        Database.books.put(id, book);
        return Response.status(Response.Status.CREATED).entity(book).build();
    }

    @GET
    public Collection<Book> getAllBooks() {
        return Database.books.values();
    }

    @GET
    @Path("/{id}")
    public Response getBookById(@PathParam("id") int id) {
        Book book = Database.books.get(id);
        if (book == null) {
            throw new BookNotFoundException("Book with ID " + id + " not found.");
        }
        return Response.ok(book).build();
    }

    @PUT
    @Path("/{id}")
    public Response updateBook(@PathParam("id") int id, Book updatedBook) {
        Book existingBook = Database.books.get(id);
        if (existingBook == null) {
            throw new BookNotFoundException("Book with ID " + id + " not found.");
        }
        updatedBook.setId(id);
        Database.books.put(id, updatedBook);
        return Response.ok(updatedBook).build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteBook(@PathParam("id") int id) {
        Book removed = Database.books.remove(id);
        if (removed == null) {
            throw new BookNotFoundException("Book with ID " + id + " not found.");
        }
        return Response.noContent().build();
    }
}
