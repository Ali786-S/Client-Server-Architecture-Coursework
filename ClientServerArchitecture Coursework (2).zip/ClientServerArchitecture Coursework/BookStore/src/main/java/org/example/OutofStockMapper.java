package org.example;

import jakarta.ws.rs.core.*;
import jakarta.ws.rs.ext.*;

@Provider
public class OutofStockMapper implements ExceptionMapper<OutOfStockException> {
    @Override
    public Response toResponse(OutOfStockException ex) {
        return Response.status(Response.Status.NOT_FOUND)
                .entity(new ErrorMessage("Item is out of Stock", ex.getMessage()))
                .type(MediaType.APPLICATION_JSON)
                .build();
    }
}
