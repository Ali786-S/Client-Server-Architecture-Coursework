
package org.example;

import jakarta.ws.rs.core.*;
        import jakarta.ws.rs.ext.*;

@Provider
public class CustomerNotFoundMapper implements ExceptionMapper<CustomerNotFoundException> {
    @Override
    public Response toResponse(CustomerNotFoundException ex) {
        return Response.status(Response.Status.NOT_FOUND)
                .entity(new ErrorMessage("Customer Not Found", ex.getMessage()))
                .type(MediaType.APPLICATION_JSON)
                .build();
    }
}
