package org.example;

import jakarta.ws.rs.core.*;
import jakarta.ws.rs.ext.*;

@Provider
public class AuthorNotFoundMapper implements ExceptionMapper<AuthorNotFoundException> {
    @Override
    public Response toResponse(AuthorNotFoundException ex) {
        return Response.status(Response.Status.NOT_FOUND)
                .entity(new ErrorMessage("Author Not Found", ex.getMessage()))
                .type(MediaType.APPLICATION_JSON)
                .build();
    }
}
