package org.example;
public class Author {
    private int id;
    private String name;
    private String surname;



    private String biography;

    public Author() {}

    public Author(String name, String surname, String biography, int id) {
        this.name = name;
        this.surname = surname;
        this.biography = biography;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }



    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }
}
