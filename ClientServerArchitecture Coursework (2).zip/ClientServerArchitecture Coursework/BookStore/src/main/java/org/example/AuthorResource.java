package org.example;


import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.example.Author;
import org.example.Book;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Path("/authors")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AuthorResource {
    private static Map<Integer, Book> books = Database.books;
    private static AtomicInteger authorIdCounter = new AtomicInteger(1);



    @POST
    public Response createAuthor(Author author) {
        int id = Database.authorIdCounter.getAndIncrement();
        author.setId(id);
        Database.authors.put(id, author);
        return Response.status(Response.Status.CREATED).entity(author).build();
    }

    @GET
    public Collection<Author> getAllAuthors() {
        return Database.authors.values();
    }

    @GET
    @Path("/{id}")
    public Response getAuthor(@PathParam("id") int id) {
        Author author = Database.authors.get(id);
        if (author == null) throw new AuthorNotFoundException("Author with id:" + id + "not found");
        return Response.ok(author).build();
    }

    @PUT
    @Path("/{id}")
    public Response updateAuthor(@PathParam("id") int id, Author updatedAuthor) {
        Author author = Database.authors.get(id);
        if (author == null) throw new AuthorNotFoundException("Author with id:" + id + "not found");
        updatedAuthor.setId(id);
        Database.authors.put(id, updatedAuthor);
        return Response.ok(updatedAuthor).build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteAuthor(@PathParam("id") int id) {
        Author removed = Database.authors.remove(id);
        if (removed == null) throw new AuthorNotFoundException("Author with id:" + id + "not found");
        return Response.noContent().build();
    }

    @GET
    @Path("/{id}/books")
    public Response getBooksByAuthor(@PathParam("id") int id) {

        if (!Database.authors.containsKey(id)) throw new AuthorNotFoundException("Author with id:" + id + "not found");

        List<Book> authoredBooks = new ArrayList<>();
        for (Book book : books.values()) {
            if (book.getAuthorId() == id) {
                authoredBooks.add(book);
            }
        }
        return Response.ok(authoredBooks).build();

    }

    public static Map<Integer, Author> getAuthorDB() {
        return Database.authors;
    }
}
