package org.example;


import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.example.CartItem;
import org.example.Book;
import java.util.*;

@Path("/customers/{customerId}/cart")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CartResource {

    private static Map<Integer, List<CartItem>> cartDB = Database.carts;
    private static Map<Integer, Book> books = Database.books;


    @POST
    @Path("/items")
    public Response addItem(@PathParam("customerId") int customerId, CartItem item) {
        Book book = books.get(item.getBookId());
        if (book == null){ throw new BookNotFoundException("Book with ID:" + item.getBookId() + "not found.");
        }

        cartDB.putIfAbsent(customerId, new ArrayList<>());
        List<CartItem> cart = cartDB.get(customerId);

        for (CartItem ci : cart) {
            if (ci.getBookId() == item.getBookId()) {
                ci.setQuantity(ci.getQuantity() + item.getQuantity());
                return Response.ok(ci).build();
            }
        }

        cart.add(item);
        return Response.status(Response.Status.CREATED).entity(item).build();
    }

    @GET
    @Path("/items")
    public Response viewCart(@PathParam("customerId") int customerId) {
        List<CartItem> cart = cartDB.getOrDefault(customerId, new ArrayList<>());
        return Response.ok(cart).build();
    }

    @PUT
    @Path("/items/{bookId}")
    public Response updateItem(@PathParam("customerId") int customerId, @PathParam("bookId") int bookId, CartItem update) {
        List<CartItem> cart = cartDB.get(customerId);
        if (cart == null) throw new CartNotFoundException("Cart for customer ID:" + customerId + "not found.");

        for (CartItem item : cart) {
            if (item.getBookId() == bookId) {
                item.setQuantity(update.getQuantity());
                return Response.ok(item).build();
            }
        }

        throw new BookNotFoundException("Book with ID:" + bookId + "not found in cart.");
    }

    @DELETE
    @Path("/items/{bookId}")
    public Response removeItem(@PathParam("customerId") int customerId, @PathParam("bookId") int bookId) {
        List<CartItem> cart = cartDB.get(customerId);
        if (cart == null){throw new CartNotFoundException("Cart for customer ID:" + customerId + "not found.");}

        boolean removed = cart.removeIf(item -> item.getBookId() == bookId);
        if (!removed){
            throw new BookNotFoundException("Book with ID:" + bookId + "not found in cart.");
        }
        return Response.noContent().build();
    }

    public static Map<Integer, List<CartItem>> getCartDB() {
        return cartDB;
    }
}
